//
// Created by hantao on 8/4/19.
//

#ifndef BSPATHCH_COMM_H
#define BSPATHCH_COMM_H

#include "include/minilzo.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#define IN_LEN      (2280*1024ul)
#define OUT_LEN     (IN_LEN + IN_LEN / 16 + 64 + 3)
static unsigned char __LZO_MMODEL in  [ IN_LEN ];
static unsigned char __LZO_MMODEL myout [ OUT_LEN ];




struct bspatch_stream
{
    void* opaque;
    void* wfd;
    int (*read)(const struct bspatch_stream* stream, void* buffer, int length);
    int (*write)(const struct bspatch_stream* stream, void *wBuffer, int length);

} ;

struct file_head{
    uint32_t size;
    uint8_t  flag;
    uint8_t  oldversion;
    uint8_t  newversion;
    uint32_t  crc32;
}__attribute__((packed));
int32_t  offtin(uint8_t *buf);
int patch_read(const struct bspatch_stream* stream, void* buffer, int length);
int bspatch(const uint8_t* old, int32_t oldsize, uint8_t* new, int32_t newsize, int32_t start,struct bspatch_stream* stream);

int blcok_patch(uint32_t *newpos,uint32_t *oldpos,uint32_t oldoffset,uint8_t* old);

int patch_write(const struct bspatch_stream* stream, void *wBuffer, int length);
uint32_t crc32_stream(uint32_t pre_crc, uint8_t *p,  uint32_t len);


#endif //BSPATHCH_COMM_H
