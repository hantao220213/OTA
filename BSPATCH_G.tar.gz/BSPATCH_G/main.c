#include <stdio.h>
#include "comm.h"
int main(int argc , char *argv[])
{

    printf("Hello, World!\n");
    FILE * f=NULL,*wf=NULL;
    int fd;
    uint8_t *old=NULL, *new=NULL;
    int32_t oldsize, newsize;
    struct bspatch_stream stream;
    struct  stat sb;
    if(argc <=  4)
    {
        printf("usage: %s oldfile newfile patchfile\n",argv[0]);
        return 0;
    }

    if(lzo_init() != LZO_E_OK)
    {
        printf("[%s][%s][%d] lzo_init failed\n",__FILE__,__FUNCTION__,__LINE__);
        return 0;
    }

    //test
    int r;

    FILE * tf= NULL ;
    tf = fopen(argv[3],"r");
    if (tf == NULL)
    {
        printf("[%s][%s][%d] open file failed \n",__FILE__,__FUNCTION__,__LINE__);
        return 0;
    }

    struct file_head fileHead;

    if ((fread((char *)&fileHead,sizeof(struct file_head),1,tf))!=1)
    {
        printf("[%s][%s][%d] get bsdiff file header failed\n",__FILE__,__FUNCTION__,__LINE__);
        return 0;
    }


    int filesize = fileHead.size;
    printf("[%s][%s][%d] readfilesize [%d]\n",__FILE__,__FUNCTION__,__LINE__,filesize);


    int flag = fileHead.flag;
    printf("[%s][%s][%d] flag [%d]\n",__FILE__,__FUNCTION__,__LINE__,flag);

    int oldv = fileHead.oldversion;
    printf("[%s][%s][%d] oldv [%d]\n",__FILE__,__FUNCTION__,__LINE__,oldv);

    int newv = fileHead.newversion;
    printf("[%s][%s][%d] newv [%d]\n",__FILE__,__FUNCTION__,__LINE__,newv);

    int crc = fileHead.crc32;
    printf("[%s][%s][%d] crc [%d]\n",__FILE__,__FUNCTION__,__LINE__,crc);

    /* Close patch file and re-open it via libbzip2 at the right places */
    if(((fd=open(argv[1],O_RDONLY,0))<0) ||
       ((oldsize=lseek(fd,0,SEEK_END))==-1) ||
       ((old=malloc(oldsize+1))==NULL) ||
       (lseek(fd,0,SEEK_SET)!=0) ||
       (read(fd,old,oldsize)!=oldsize) ||
       (fstat(fd, &sb)) ||
       (close(fd)==-1))
    {
        printf("[%s][%s][%d] read file(%s) failed\n",__FILE__,__FUNCTION__,__LINE__,argv[1]);
        goto ERR;
    }

    printf("[%s][%s][%d] oldsize [%d]\n",__FILE__,__FUNCTION__,__LINE__,oldsize);

    FILE *ff = fopen(argv[2],"w+");
    if (ff == NULL)
    {
        printf("[%s][%s][%d] read file(%s) failed\n",__FILE__,__FUNCTION__,__LINE__,argv[2]);
        goto ERR;
    }
    stream.write = patch_write;
    stream.wfd=ff;
    stream.read=patch_read;
    stream.opaque=tf;

    struct write_diff writeDiff;
    FILE *lzofd=NULL;

    lzofd = fopen(argv[4],"w+");
    if (lzofd == NULL)
    {
        printf("[%s][%s][%d] write lzo docmompress(%s) failed\n",__FILE__,__FUNCTION__,__LINE__,argv[4]);
        goto ERR;
    }
    writeDiff.fd=lzofd;
    writeDiff.write=lzo_write;


    printf("argcv[1]: %s\n",argv[1]);
    printf("argcv[2]: %s\n",argv[2]);
    printf("argcv[3]: %s\n",argv[3]);
    printf("argcv[4]: %s\n",argv[4]);

    while (!feof(tf)) {
        uint8_t TL[16] = {'\0'};
        uint32_t blocknum = -1;
        uint32_t compressLen = 0;
        lzo_uint in_len;
        lzo_uint out_len;

        if (fread(TL, 16, 1, tf) != 1) {
            if (feof(tf))
                return 0;
            printf("[%s][%s][%d] read compress header failed\n", __FILE__, __FUNCTION__, __LINE__);
            goto ERR;
        }
        blocknum = offtin(TL);
        in_len = offtin(TL + 8);
        printf("[%s][%s][%d] ---------blcok--------- number :[%d]\n", __FILE__, __FUNCTION__, __LINE__, blocknum);
        printf("[%s][%s][%d] blcok in_len :[%d]\n", __FILE__, __FUNCTION__, __LINE__, in_len);

        memset(in, 0x00, in_len);

        if (fread(in, in_len, 1, tf) != 1) {
            printf("[%s][%s][%d] read compress data failed\n", __FILE__, __FUNCTION__, __LINE__);
            goto ERR;
        }

        memset(myout,0x00,OUT_LEN);

        r = lzo1x_decompress(in, in_len, myout, &out_len, NULL/*,&writeDiff*/);
        if (r != LZO_E_OK) {
            printf("[%s][%s][%d] lzo1x_decompress failed,r : %d\n", __FILE__, __FUNCTION__, __LINE__, r);
            goto ERR;
        }
        printf("[%s][%s][%d] -----------------out_len : %d\n", __FILE__, __FUNCTION__, __LINE__, out_len);
        //writeDiff.write(&writeDiff,myout,out_len);


        uint8_t point[8] = {'\0'};
        memcpy(point, myout, 8);
        int start = offtin(point);
        printf("[%s][%s][%d] start : %d\n", __FILE__, __FUNCTION__, __LINE__, start);

        int ret = -1;
        if ((ret = bspatch(old, oldsize, myout + 8, out_len - 8, start, &stream)) < 0) {
            printf("[%s][%s][%d] bspatch failed\n", __FILE__, __FUNCTION__, __LINE__);
            goto ERR;
        }
        printf("[%s][%s][%d] bspatch sucess\n", __FILE__, __FUNCTION__, __LINE__);

    }




ERR:
    if (lzofd != NULL)
        fclose(lzofd);
    if (f != NULL)
        fclose(f);
    if (wf != NULL)
        fclose(wf);
    if (new != NULL)
        free(new);
    if (old != NULL)
        free(old);
    return 0;
}