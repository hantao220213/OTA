//
// Created by hantao on 8/4/19.
//

#include "comm.h"
int32_t  offtin(uint8_t *buf)
{
    int32_t y;

    y=buf[3]&0x7F;
    y=y*256;y+=buf[2];
    y=y*256;y+=buf[1];
    y=y*256;y+=buf[0];

    if(buf[3]&0x80) y=-y;

    return y;
}

int patch_read(const struct bspatch_stream* stream, void* buffer, int length)
{

    printf("[%s][%s][%d] patch_read start ,length :%d\n",__FILE__,__FUNCTION__,__LINE__,length);

    if (length == 0 )
        return 0;
    int n;
    FILE* fd=NULL;
    fd = (FILE*)stream->opaque;
    int npoint = ftell(fd);
    printf("[%s][%s][%d] patch_read start ftell,npoint :%d\n",__FILE__,__FUNCTION__,__LINE__,npoint);

    n = fread(buffer, length, 1, fd);
    if (n != 1)
    {
        printf("[%s][%s][%d] fread file failed,ret : %d,errno:%d,errmsg: %s\n",__FILE__,__FUNCTION__,__LINE__,n,errno,strerror(errno));
        return -1;
    }
    printf("[%s][%s][%d] fread file sucess,buffer : {%s}\n",__FILE__,__FUNCTION__,__LINE__,buffer);

    return 0;
}

int bspatch(const uint8_t* old, int32_t oldsize, uint8_t* new, int32_t newsize, int32_t start,struct bspatch_stream* stream)
{
    int32_t oldpos,newpos;
    int32_t ctrl[3];
    int32_t i;

    oldpos=0;newpos=0;
    uint8_t buf[8*3]={'\0'};
    int flag=1;
    oldpos+=start;
    int offset=0;
    char bsbuff[OUT_LEN]={'\0'};
    printf("[%s][%s][%d] newsize: %d,start: %d\n",__FILE__,__FUNCTION__,__LINE__,newsize,start);

    while (offset < newsize)
    {

        printf("[%s][%s][%d] offset[%d] \n",__FILE__,__FUNCTION__,__LINE__,offset);
        printf("[%s][%s][%d] oldpos[%d] \n",__FILE__,__FUNCTION__,__LINE__,oldpos);

        memcpy(buf,new+offset,24);
        uint8_t sctr[3][8]={'\0'};
        memcpy(sctr[0],buf,8);
        ctrl[0]=offtin(sctr[0]);
        printf("[%s][%s][%d] ctrLen[0][%d] \n",__FILE__,__FUNCTION__,__LINE__,ctrl[0]);

        memcpy(sctr[1],buf+8,8);
        ctrl[1] = offtin(sctr[1]);
        printf("[%s][%s][%d] ctrLen[1][%d] \n",__FILE__,__FUNCTION__,__LINE__,ctrl[1]);

        memcpy(sctr[2],buf+16,8);
        ctrl[2] = offtin(sctr[2]);

        printf("[%s][%s][%d] ctrLen[2][%d] \n",__FILE__,__FUNCTION__,__LINE__,ctrl[2]);
        if(!(ctrl[0]|ctrl[1]|ctrl[2]))
        {
            printf("[%s][%s][%d] 最后一个数据结束 \n",__FILE__,__FUNCTION__,__LINE__);
            return 0;
        }
        /* Sanity-check */
        if(newpos+ctrl[0]>newsize)
        {
            printf("Sanity-check newpos : %d\n",newpos);
            printf("Sanity-check newpos+ctrl[0] : %d\n",newpos+ctrl[0]);
            printf("Sanity-check newsize : %d\n",newsize);
            return -1;
        }

        offset+=24;
        printf("[%s][%d] offset+=ctrl[0]; offset : %d\n",__FUNCTION__,__LINE__,offset);

        /* Read diff string */
        memcpy(bsbuff,new+offset,ctrl[0]);
        printf("[%s][%d]write string new:{%s}\n",__FUNCTION__,__LINE__,new);

        printf("---------------------------------------------------1------------------------------------------------------------\n");
        printf("[%s][%d]write string oldpos:{%d}\n",__FUNCTION__,__LINE__,oldpos);

        /* Add old data to diff string */
        for(i=0;i<ctrl[0];i++){
            if((oldpos+i>=0) && (oldpos+i<oldsize))
                bsbuff[i]+=old[oldpos+i];

        }
        printf("[%s][%d]write string new:{%s}\n",__FUNCTION__,__LINE__,new);

        printf("---------------------------------------------------2------------------------------------------------------------\n");

        if (stream->write(stream,bsbuff,ctrl[0]))
        {
            printf("[%s][%s][%d] write new data failed\n",__FILE__,__FUNCTION__,__LINE__);
            return -1;
        }

        /* Adjust pointers */
        /////////////////////////////////////////////////////////////////////////////////////////////////////////
        newpos+=ctrl[0];
        oldpos+=ctrl[0];

        printf("[%s][%d]write string new:{%s}\n",__FUNCTION__,__LINE__,new);
       // printf("[%s][%d]write string old:{%s}\n",__FUNCTION__,__LINE__,old);
        printf("[%s][%s][%d] Sanity-check start--1 newpos[%d],ctrl[0][%d]\n",__FILE__,__FUNCTION__,__LINE__,newpos,ctrl[0]);
        printf("[%s][%s][%d] Sanity-check start--1 oldpos[%d],ctrl[0][%d]\n",__FILE__,__FUNCTION__,__LINE__,oldpos,ctrl[0]);
        /* Sanity-check */
        if(newpos+ctrl[1]>newsize)
        {
            printf("Sanity-check--1 newpos: %d\n",newpos);
            printf("Sanity-check--1 ctrl[1]: %d\n",ctrl[1]);
            printf("Sanity-check--1 newpos+ctrl[1]: %d\n",newpos+ctrl[1]);
            printf("Sanity-check--1 newsize: %d\n",newsize);
            return -1;
        }

        printf("[%s][%d]Read extra string start newpos: [%d], ctrl[1]:[%d]\n",__FUNCTION__,__LINE__,newpos, ctrl[1]);
        /* Read extra string */

        offset+=ctrl[0];
        printf("[%s][%d] offset+=ctrl[0]; offset : %d\n",__FUNCTION__,__LINE__,offset);

        memcpy(bsbuff,new+offset,ctrl[1]);
        printf("[%s][%d]write string new:{%s}\n",__FUNCTION__,__LINE__,new+newpos);
        printf("---------------------------------------------------3------------------------------------------------------------\n");
        if (stream->write(stream,bsbuff,ctrl[1]))
        {
            printf("[%s][%s][%d] write new data failed\n",__FILE__,__FUNCTION__,__LINE__);
            return -1;
        }
        offset+=ctrl[1];
        /* Adjust pointers */
        newpos+=ctrl[1];
        oldpos+=ctrl[2];
        printf("[%s][%d] next loop ctrl[1] : %d\n",__FUNCTION__,__LINE__,ctrl[1]);
        printf("[%s][%d] next loop ctrl[2] : %d\n",__FUNCTION__,__LINE__,ctrl[2]);
        printf("[%s][%d] next loop newpos : %d\n",__FUNCTION__,__LINE__,newpos);
        printf("[%s][%d] next loop oldpos : %d\n",__FUNCTION__,__LINE__,oldpos);
        printf("[%s][%d] next loop offset : %d\n",__FUNCTION__,__LINE__,offset);


    };


    return 0;
}

int patch_write(const struct bspatch_stream* stream, void *wBuffer, int length)
{

    printf("[%s][%s][%d] patch_write start,length: %d\n",__FILE__,__FUNCTION__,__LINE__,length);
    if (length == 0)
        return 0;

    int n = fwrite(wBuffer,length,1,(FILE*)stream->wfd);
    if (n != 1)
    {
        printf("[%s][%s][%d] patch_write failed,n: %d\n",__FILE__,__FUNCTION__,__LINE__,n);
        return -1;
    }
    printf("[%s][%s][%d] patch_write sucessn: %d\n",__FILE__,__FUNCTION__,__LINE__,n);
    return 0;
}
uint32_t crc32_stream(uint32_t pre_crc, uint8_t *p,  uint32_t len)
{
    int i;
    uint32_t crc = pre_crc;
    while (len--) {
        crc ^= *p++;
        for (i = 0; i < 8; i++)
            crc = (crc >> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
    }
    return crc;
}

int lzo_write(const  struct write_diff *writeDiff, void *wBuffer, int length)
{

   // printf("[%s][%s][%d] patch_write start,length: %d\n",__FILE__,__FUNCTION__,__LINE__,length);
    if (length == 0)
        return 0;

    int n = fwrite(wBuffer,length,1,(FILE*)writeDiff->fd);
    if (n != 1)
    {
        printf("[%s][%s][%d] patch_write failed,n: %d\n",__FILE__,__FUNCTION__,__LINE__,n);
        return -1;
    }
   // printf("[%s][%s][%d] patch_write sucessn: %d\n",__FILE__,__FUNCTION__,__LINE__,n);
    return 0;
}