说明：
    1.目录
        1)$HOME/BSPATCH_G/bin/Debug/ ：可执行文件,脚本,固件以及中间文件
        2)$HOME/BSPATCH_G/bin/Debug/version/：bin文件目录集
        3)$HOME/BSPATCH_G/bin/Debug/version/old:所有老固件存放目录
        4)$HOME/BSPATCH_G/bin/Debug/version/new:最新固件存放目录
        5)$HOME/BSPATCH_G/bin/Debug/version/diff:所有差分压缩文件存放目录
        6)$HOME/BSPATCH_G/bin/Debug/version/doCompress:解压缩后的差分文件
        7)$HOME/BSPATCH_G/bin/Debug/version/patch:还原后的新固件存放目录
        8)$HOME/BSPATCH_G/bin/Debug/version/log:差分压缩还原算法日志存放目录
    2.文件
        1)bspatch.sh:差分压缩还原工具执行脚本；
    3.操作
        1)cd $HOME/BSPATCH_G/bin/Debug/目录下;
        2)执行chmod +x bspatch.sh 命令
        3)执行./bspatch.sh 命令
        4)在linux环境 vim -d NEW_A232_V11.0-H1.0-R.bin A232_V11.0-H1.0-R.bin 查看还原的固件是否和新固件完全一样,
          验证差分压缩固件的正确性
    4.注意：
        1)当myself dir 和exmple不同时,将bspatch.sh脚本中的PATH等信息修改为自己的目录信息，如上述实例
        2)本实例是在ubuntu14.04_x64编译完成,在其他操作系统不能执行时,依次执行如下命令：
           cd $HOME/BSPATCH_G/
           rm CMakeCache.txt
           cmake -f CMakeLists.txt
           make



