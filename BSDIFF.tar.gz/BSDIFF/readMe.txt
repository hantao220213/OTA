说明：
    1.目录
        1)$HOME/BSDIFF/bin/Debug/ ：可执行文件,脚本,固件以及中间文件
        2)$HOME/BSDIFF/bin/Debug/version/：bin文件目录集
        3)$HOME/BSDIFF/bin/Debug/version/old:所有老固件存放目录
        4)$HOME/BSDIFF/bin/Debug/version/new:最新固件存放目录
        5)$HOME/BSDIFF/bin/Debug/version/diff:所有差分压缩文件存放目录
        8)$HOME/BSDIFF/bin/Debug/version/log:差分压缩还原算法日志存放目录
    2.文件
        1)bsdiff.sh:差分压缩还原工具执行脚本；
    3.操作
        1)cd $HOME/BSDIFF/bin/Debug/目录下;
        2)执行chmod +x bsdiff.sh 命令
        3)执行./bspatch.sh 命令
    4.注意：
        1)当脚本中的目录和当前目录不同时,bsdiff.sh脚本中的PATH等信息修改为自己的目录信息，如上述实例
        2)本实例是在ubuntu14.04_x64编译完成,在其他操作系统不能执行时,依次执行如下命令：
           cd $HOME/BSDIFF/
           rm CMakeCache.txt
           cmake -f CMakeLists.txt
           make
        3)固件版本的命名规则：A232_Vx-Hx-R.bin(例如：A232_V1.0-H1.0-R.bin,Vx软件版本号,Hx硬件版本号)

