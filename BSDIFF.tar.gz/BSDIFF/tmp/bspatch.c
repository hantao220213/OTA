/*-
 * Copyright 2003-2005 Colin Percival
 * Copyright 2012 Matthew Endsley
 * All rights reserved
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted providing that the following conditions 
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "bspatch.h"
#include <stdio.h>

static int64_t offtin(uint8_t *buf)
{
	int64_t y;

	y=buf[7]&0x7F;
	y=y*256;y+=buf[6];
	y=y*256;y+=buf[5];
	y=y*256;y+=buf[4];
	y=y*256;y+=buf[3];
	y=y*256;y+=buf[2];
	y=y*256;y+=buf[1];
	y=y*256;y+=buf[0];

	if(buf[7]&0x80) y=-y;

	return y;
}

int bspatch(const uint8_t* old, int64_t oldsize, uint8_t* new, int64_t newsize, struct bspatch_stream* stream)
{
	uint8_t buf[8];
	int64_t oldpos,newpos;
	int64_t ctrl[3];
	int64_t i;

	oldpos=0;newpos=0;
	uint8_t tmp;
	static int count=0;
	while(newpos<newsize) {
		

		//取2次
		if(count >1)
			return 0;
		count++;

		/*
		uint8_t *new=malloc(newsize+1);
		uint8_t *old=malloc(oldsize+1);
		uint8_t *new1=malloc(newsize+1);
		*/
		/* Read control data */
		for(i=0;i<=2;i++) {
			if (stream->read(stream, buf, 8))
			//if (stream->read(stream,0,buf, 8) < 0)
			{
				printf("[%d] buf: %s\n",__LINE__,buf);
				return -1;
			}
			ctrl[i]=offtin(buf);
			printf("[%s][%d]ctrl[%d] : %d\n",__FUNCTION__,__LINE__,i,ctrl[i]);
			
		};

		printf("[%s][%d] Sanity-check start newpos[%d],ctrl[0][%d]\n",__FUNCTION__,__LINE__,newpos,ctrl[0]);
		/* Sanity-check */
		if(newpos+ctrl[0]>newsize)
		{
			printf("Sanity-check newpos : %d\n",newpos);
			printf("Sanity-check newpos+ctrl[0] : %d\n",newpos+ctrl[0]);
			printf("Sanity-check newsize : %d\n",newsize);
			return -1;
		}
		
		
		#if 1
		/* Read diff string */
		if (stream->read(stream, new + newpos, ctrl[0]))
		//if (stream->read(stream, new, ctrl[0]))
		{
			printf("Read diff string ctrl[0] : %d\n",ctrl[0]);
				
			return -1;
		}
		printf("[%s][%d]write string new:{%s}\n",__FUNCTION__,__LINE__,new+newpos);	
		printf("---------------------------------------------------1------------------------------------------------------------\n");	
		
		/* Add old data to diff string */
		for(i=0;i<ctrl[0];i++){
			if((oldpos+i>=0) && (oldpos+i<oldsize))
				new[newpos+i]+=old[oldpos+i];

		}
		#endif
		printf("[%s][%d]write string new:{%s}\n",__FUNCTION__,__LINE__,new+newpos);	
		printf("---------------------------------------------------2------------------------------------------------------------\n");	
	
		//printf("[[%s][%d]Add old data to diff string new: {%s}\n",__FUNCTION__,__LINE__,new);
		//printf("[[%s][%d]Add old data to diff string old: {%s}\n",__FUNCTION__,__LINE__,old);
		/* Adjust pointers */
		#if 0
		if (stream->read(stream,newpos,new, ctrl[0]) < 0)
		{
			
			printf("[%s][%d]Read diff string ctrl[0]:{%d},newpos:[%d]\n",__FUNCTION__,__LINE__,ctrl[0],newpos);	
			return -1;
		}
		printf("[%s][%d]Read diff string new:{%s}\n",__FUNCTION__,__LINE__,new);
		if(stream->readOLD(stream,oldpos,old, ctrl[0]) < 0)
		{
			printf("[%s][%d]Read old string ctrl[0]:{%d},oldpos:[%d]\n",__FUNCTION__,__LINE__,ctrl[0],oldpos);	
			return -1;	
		}
		printf("[%s][%d]Read diff string old:{%s}\n",__FUNCTION__,__LINE__,old);
		new[0]+=tmp;
		for(i=0;i<ctrl[0];i++){
			if((oldpos+i>=0) && (oldpos+i<oldsize))
			{
				new[i]+=old[i];
			}
			
		}
		
		printf("[%s][%d]write string new:{%s}\n",__FUNCTION__,__LINE__,new);
		int wLen= strlen(new);
		if(stream->write(stream,new,/*ctrl[0]*/wLen)<0)
		{
			printf("[%s][%s][%d] wite file failed\n",__FILE__,__FUNCTION__,__LINE__);
			return -1;
		}
		
		char *fg="--------------------------------------------------------1--------------------------------------------------------------------------------\n";
		if(stream->write(stream,fg,strlen(fg))<0)
		{
			printf("[%s][%s][%d] wite fengef file failed\n",__FILE__,__FUNCTION__,__LINE__);
			return -1;
		}
		printf("[%s][%d] fengefu:%s\n",__FUNCTION__,__LINE__,fg);
		#endif
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
		newpos+=ctrl[0];
		oldpos+=ctrl[0];

		printf("[%s][%d] Sanity-check start--1 newpos[%d],ctrl[0][%d]\n",__FUNCTION__,__LINE__,newpos,ctrl[0]);
		printf("[%s][%d] Sanity-check start--1 oldpos[%d],ctrl[0][%d]\n",__FUNCTION__,__LINE__,oldpos,ctrl[0]);
		/* Sanity-check */
		if(newpos+ctrl[1]>newsize)
		{
			printf("Sanity-check--1 newpos: %d\n",newpos);
			printf("Sanity-check--1 ctrl[1]: %d\n",ctrl[1]);
			printf("Sanity-check--1 newpos+ctrl[1]: %d\n",newpos+ctrl[1]);
			printf("Sanity-check--1 newsize: %d\n",newsize);
			return -1;
		}

		printf("[%s][%d]Read extra string start newpos: [%d], ctrl[1]:[%d]\n",__FUNCTION__,__LINE__,newpos, ctrl[1]);
		#if 1
		/* Read extra string */
		if (stream->read(stream, new + newpos, ctrl[1]))
		{
			printf("Read extra string newpos: %d\n",newpos);
			printf("Read extra string ctrl[1]: %d\n",ctrl[1]);

			return -1;
		}
		#endif
		printf("[%s][%d]write string new:{%s}\n",__FUNCTION__,__LINE__,new+newpos);	
		printf("---------------------------------------------------3------------------------------------------------------------\n");	
		#if 0
		if(stream->read(stream,newpos,new1, ctrl[1]) < 0)
		{
			printf("[%s][%s][%d] Read extra string \n",__FILE__,__FUNCTION__,__LINE__);
			return -1;
		}
		printf("[%s][%d]Read extra string  new:{%s}\n",__FUNCTION__,__LINE__,new);

		for(i=0;i<ctrl[1];i++){
			if((oldpos+i>=0) && (oldpos+i<oldsize))
			{
				new1[i]+=new1[i+1];
			}
			
		}
		if(stream->write(stream,new1,ctrl[0]/2)<0)
		{
			printf("[%s][%s][%d] wite file failed\n",__FILE__,__FUNCTION__,__LINE__);
			return -1;
		}
		tmp=new1[ctrl[1]-1];
		#endif 
		/* Adjust pointers */
		newpos+=ctrl[1];
		oldpos+=ctrl[2];
		printf("[%s][%d] next loop ctrl[1] : %d\n",__FUNCTION__,__LINE__,ctrl[1]);
		printf("[%s][%d] next loop ctrl[2] : %d\n",__FUNCTION__,__LINE__,ctrl[2]);
		printf("[%s][%d] next loop newpos : %d\n",__FUNCTION__,__LINE__,newpos);
		printf("[%s][%d] next loop oldpos : %d\n",__FUNCTION__,__LINE__,oldpos);
		
		#if 0
		/* my test start-------------------------*/
		char *fg1="---------------------------------------------------------2-------------------------------------------------------------------------------\n";
		if(stream->write(stream,fg1,strlen(fg1))<0)
		{
			printf("[%s][%s][%d] wite fengef file failed\n",__FILE__,__FUNCTION__,__LINE__);
			return -1;
		}
		printf("[%s][%d] fengefu:%s\n",__FUNCTION__,__LINE__,fg1);
		free(new);
		free(old);	
		/* my test end-------------------------*/
		#endif
	};


	return 0;
}

#if defined(BSPATCH_EXECUTABLE)

#include <bzlib.h>
#include <stdlib.h>
#include <stdint.h>
//#include <stdio.h>
#include <string.h>
#include <err.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#if 0
static int myWrite(const struct bspatch_stream* stream,void *buffer,int length)
{
	if(length == 0)
		return 0;
	FILE *wfd;
	wfd = (FILE*)stream->wfd;
	//fseek(wfd,0,SEEK_END);
	if(fwrite(buffer,length,1,wfd) !=1)
	{
		printf("[%s][%d]fwrite file failed------errmsg{%s}\n",__FUNCTION__,__LINE__,buffer);
		return -1;
	}
	return 0;
}
static int myRead(const struct bspatch_stream* stream,int newpos,void* buffer, int length)
{
	int n;
	int bz2err;
	FILE *rfd;

	if(length == 0)
		return 0;
	rfd = (FILE*)stream->opaque;

	//int mm=0;
	//mm = ftell(rfd);
	//printf("[%s][%d] ftell : %d\n",__FUNCTION__,__LINE__,mm);
	//fseek(rfd,newpos,SEEK_SET);
	n = fread(buffer,length,1,rfd);
	if (n != 1)
	{	printf("[%s][%d]n:%d,length: %d\n",__FUNCTION__,__LINE__,n,length);
		printf("[%s][%d]buffer :%s\n",__FUNCTION__,__LINE__,buffer);
		return -1;
	}
	return 0;
}
static int myReadOLD(const struct bspatch_stream* stream,int oldpos,void* buffer, int length)
{
	int n;
	int bz2err;
	FILE *rfd;

	if(length == 0)
		return 0;
	rfd = (FILE*)stream->oldfd;
	//int mm = ftell(rfd);
	//fseek(rfd,oldpos,SEEK_SET);
	n = fread(buffer,length,1,rfd);
	if (n != 1)
	{	printf("[%s][%d]n:%d,length: %d\n",__FUNCTION__,__LINE__,n,length);
		printf("[%s][%d]buffer :%s\n",__FUNCTION__,__LINE__,buffer);
		return -1;
	}
	return 0;
}
#endif
#if 1
static int bz2_read(const struct bspatch_stream* stream, void* buffer, int length)
{
	int n;
	int bz2err;
	BZFILE* bz2;

	bz2 = (BZFILE*)stream->opaque;
	n = BZ2_bzRead(&bz2err, bz2, buffer, length);
	if (n != length)
		return -1;

	return 0;
}
#endif
#if 0
static int bz2_read(const struct bspatch_stream* stream, void* buffer, int length)
{
	int n;
	int bz2err;
	FILE* bz2;

	if(length == 0)
		return 0;
	bz2 = (FILE*)stream->opaque;
	n = fread(buffer,length,1,bz2);
	//n = read(bz2,buffer,length);
	if (n != 1)
	{	printf("[%s][%d]n:%d,length: %d\n",__FUNCTION__,__LINE__,n,length);
		printf("[%s][%d]buffer :%s\n",__FUNCTION__,__LINE__,buffer);
		return -1;
	}
	return 0;
}
#endif
int main(int argc,char * argv[])
{
	FILE * f;
	int fd;
	int bz2err;
	uint8_t header[24];
	uint8_t *old, *new;
	int64_t oldsize, newsize;
	BZFILE* bz2;
	struct bspatch_stream stream;
	struct stat sb;

	if(argc!=4) errx(1,"usage: %s oldfile newfile patchfile\n",argv[0]);

	/* Open patch file */
	if ((f = fopen(argv[3], "r")) == NULL)
		err(1, "fopen(%s)", argv[3]);

	/* Read header */
	if (fread(header, 1, 24, f) != 24) {
		if (feof(f))
			errx(1, "Corrupt patch\n");
		err(1, "fread(%s)", argv[3]);
	}

	/* Check for appropriate magic */
	if (memcmp(header, "ENDSLEY/BSDIFF43", 16) != 0)
		errx(1, "Corrupt patch\n");

	/* Read lengths from header */
	newsize=offtin(header+16);
	if(newsize<0)
		errx(1,"Corrupt patch\n");
	printf("newsize : %d\n",newsize);
	/* Close patch file and re-open it via libbzip2 at the right places */
	if(((fd=open(argv[1],O_RDONLY,0))<0) ||
		((oldsize=lseek(fd,0,SEEK_END))==-1) ||
		((old=malloc(oldsize+1))==NULL) ||
		(lseek(fd,0,SEEK_SET)!=0) ||
		(read(fd,old,oldsize)!=oldsize) ||
		(fstat(fd, &sb)) ||
		(close(fd)==-1)) err(1,"%s",argv[1]);
	if((new=malloc(newsize+1))==NULL) err(1,NULL);
	#if 1
	if (NULL == (bz2 = BZ2_bzReadOpen(&bz2err, f, 0, 0, NULL, 0)))
		errx(1, "BZ2_bzReadOpen, bz2err=%d", bz2err);

	stream.read = bz2_read;
	stream.opaque = bz2;
	#endif
	
	stream.read = bz2_read;
	#if 0
	stream.read = myRead;
	stream.readOLD = myReadOLD;
	stream.write = myWrite;
	#endif

	#if 0
	stream.opaque = f;

	FILE *wfd;
	FILE *rfd;
	if((wfd = fopen(argv[2],"a+"))== NULL)
	{
		printf("open witre file failed \n");
		return -1;
	}
	if((rfd = fopen(argv[1],"r"))== NULL)
	{
		printf(" open read file failed \n");
		return -1;
	} 
	#endif

	#if 0
	stream.wfd=wfd;
	stream.oldfd=rfd;
	#endif
	//printf("oldsize :%d ,old: %s\n",oldsize,old);
	//printf("newsize : %d,new : %s\n",newsize,new);
	printf("[%s][%d]oldsize :%d \n",__FUNCTION__,__LINE__,oldsize);
	printf("[%s][%d]newsize : %d\n",__FUNCTION__,__LINE__,newsize);
	if (bspatch(old, oldsize, new, newsize, &stream))
		errx(1, "bspatch");

	#if 1
	/* Clean up the bzip2 reads */
	BZ2_bzReadClose(&bz2err, bz2);
	#endif

	


	#if 1
	/* Write the new file */
	if(((fd=open(argv[2],O_CREAT|O_TRUNC|O_WRONLY,sb.st_mode))<0) ||
		(write(fd,new,newsize)!=newsize) || (close(fd)==-1))
		err(1,"%s",argv[2]);
	#endif

	
	fclose(f);
	#if 0
	fclose(wfd);
	fclose(rfd);
	#endif
	free(new);
	free(old);

	return 0;
}

#endif
