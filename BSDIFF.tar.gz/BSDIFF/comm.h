//
// Created by hantao on 19-8-2.
//

#ifndef BSDIFF_COMM_H
#define BSDIFF_COMM_H

#include <stdint.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdbool.h>

#include "include/minilzo.h"
#define HEAP_ALLOC(var,size) \
    lzo_align_t __LZO_MMODEL var [ ((size) + (sizeof(lzo_align_t) - 1)) / sizeof(lzo_align_t) ]

static HEAP_ALLOC(wrkmem, LZO1X_1_MEM_COMPRESS);
#define MIN(x,y) (((x)<(y)) ? (x) : (y))
#define MAX(x,y) (((x)>(y)) ? (x) : (y))

//#define basediff 1024*10
//#define MAX_DIFF_BLOCK 50

#define CONFIG_NAME "/BS/BSDIFF/etc/config.cfg"
struct bsdiff_stream
{
    void* opaque;

    void* (*malloc)(size_t size);
    void (*free)(void* ptr);
    int (*write)(struct bsdiff_stream* stream, const void* buffer, int size);
};
struct bsdiff_request
{
    const uint8_t* old;
    int32_t oldsize;
    const uint8_t* new;
    int32_t newsize;
    struct bsdiff_stream* stream;
    int32_t *I;
    uint8_t *buffer;
};

struct file_head{
    uint32_t size;
    uint8_t  flag;
    uint8_t  oldversion;
    uint8_t  newversion;
    uint32_t  crc32;
} __attribute__ ((packed));

int lzo_write(struct bsdiff_stream *bs,const void* buffer, int size);
void offtout(int32_t x,uint8_t *buf);
int bsdiff(const uint8_t* old, int32_t oldsize, const uint8_t* new, int32_t newsize, struct bsdiff_stream* stream);
static int bsdiff_internal(const struct bsdiff_request req);
static void qsufsort(int32_t *I,int32_t *V,const uint8_t *old,int32_t oldsize);
static int32_t search(const int32_t *I,const uint8_t *old,int32_t oldsize,
                      const uint8_t *new,int32_t newsize,int32_t st,int32_t en,int32_t *pos);
static int32_t writedata(struct bsdiff_stream* stream, const void* buffer, int32_t length);
static void split(int32_t *I,int32_t *V,int32_t start,int32_t len,int32_t h);
static int32_t matchlen(const uint8_t *old,int32_t oldsize,const uint8_t *new,int32_t newsize);
int version(char *v,uint8_t *vx);
uint32_t crc32_stream(uint32_t pre_crc, uint8_t *p,  uint32_t len);

uint8_t *getConfigStr(const unsigned char *path,uint8_t *title,uint8_t *key);

uint32_t getConfigInt(const unsigned char  *path,uint8_t *title,uint8_t *key);
#endif //BSDIFF_COMM_H
