//
// Created by hantao on 19-8-2.
//


#include "comm.h"


int main(int argc,char *argv[])
{

    int fd;
    uint8_t *old,*new;
    off_t oldsize,newsize;
    //uint8_t buf[8];
    FILE * pf;
    struct bsdiff_stream stream;

    stream.malloc = (void*)malloc;
    stream.free = free;
    stream.write = (void*)lzo_write;

    if(argc!=6)
    {
        printf("usage: %s oldfile newfile patchfile\n",argv[0]);
        return 0;
    }


    //初始化miniLZO压缩
    if (lzo_init() != LZO_E_OK)
    {
        printf("internal error - lzo_init() failed !!!\n");
        printf("(this usually indicates a compiler bug - try recompiling\nwithout optimizations, and enable '-DLZO_DEBUG' for diagnostics)\n");
        return 0;
    }

    printf("[%s][%s][%d] argv[2]{%s}\n",__FILE__,__FUNCTION__,__LINE__, argv[2]);
    printf("[%s][%s][%d] argv[4]{%s}\n",__FILE__,__FUNCTION__,__LINE__, argv[4]);

    //读取老版本文件
    if(((fd=open(argv[1],O_RDONLY,0))<0) ||
       ((oldsize=lseek(fd,0,SEEK_END))==-1) ||
       ((old=malloc(oldsize+1))==NULL) ||
       (lseek(fd,0,SEEK_SET)!=0) ||
       (read(fd,old,oldsize)!=oldsize) ||
       (close(fd)==-1))
    {
        printf("[%s][%s][%d]read old file{%s}failed\n",__FILE__,__FUNCTION__,__LINE__,argv[1]);
        goto ERR;
    }
    printf("[%s][%s][%d]open old file{%s}\n",__FILE__,__FUNCTION__,__LINE__, argv[1]);

    uint8_t oldversion=0x00;
    if((version(argv[2],&oldversion))<0){
        printf("[%s][%s][%d] 获取老版本号失败\n",__FILE__,__FUNCTION__,__LINE__);
        goto ERR;
    }
    //sprintf(path,"%s%s%s",dir,"new/",argv[3]);

    //读取心版本文件
    if(((fd=open(argv[3],O_RDONLY,0))<0) ||
       ((newsize=lseek(fd,0,SEEK_END))==-1) ||
       ((new=malloc(newsize+1))==NULL) ||
       (lseek(fd,0,SEEK_SET)!=0) ||
       (read(fd,new,newsize)!=newsize) ||
       (close(fd)==-1))
    {
        printf("[%s][%s][%d] read new file{%s}\n",__FILE__,__FUNCTION__,__LINE__,argv[3]);
        goto ERR;
    }
    printf("[%s][%s][%d]open new file{%s}\n",__FILE__,__FUNCTION__,__LINE__, argv[3]);

    uint8_t newversion=0x00;
    if((version(argv[4],&newversion))<0){
        printf("[%s][%s][%d] 获取新版本号失败\n",__FILE__,__FUNCTION__,__LINE__);
        goto ERR;
    }

    uint32_t crc=crc32_stream(0,new,newsize);

    printf("[%s][%s][%d] crc32[%d]\n",__FILE__,__FUNCTION__,__LINE__,crc);
    printf("[%s][%s][%d] oldsize[%d],newsize[%d]\n",__FILE__,__FUNCTION__,__LINE__,oldsize,newsize);

    //创建差分文件
    if ((pf = fopen(argv[5], "w+")) == NULL)
    {
        printf("[%s][%s][%d]open bsdiff file{%s}\n",__FILE__,__FUNCTION__,__LINE__, argv[5]);
        goto ERR;
    }



    struct file_head fileHead;
    fileHead.size=newsize;
    fileHead.flag=1;
    fileHead.oldversion=oldversion;
    fileHead.newversion=newversion;
    fileHead.crc32=crc;
    printf("[%s][%s][%d] sizeof( struct file_head)[%d]\n",__FILE__,__FUNCTION__,__LINE__,sizeof( struct file_head));

    if (fwrite((char*)&fileHead,sizeof( struct file_head),1,pf)!=1){
        printf("write file{%s} header failed\n",argv[3]);
        goto ERR;
    }

    stream.opaque=pf;
    if (bsdiff(old, oldsize, new, newsize, &stream))
        printf("bsdiff failed\n");


    ERR:
    if (fclose(pf))
        printf("fclose failed\n");
    if (old != NULL)
        free(old);
    if (new != NULL)
        free(new);
    return 0;
}