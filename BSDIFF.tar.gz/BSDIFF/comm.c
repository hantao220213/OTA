//
// Created by hantao on 19-8-2.
//

#include <stdio.h>
#include "comm.h"

int lzo_write(struct bsdiff_stream *bs,const void* buffer, int size)
{
    printf("[%s][%s][%d] write file start,size{%d}\n",__FILE__,__FUNCTION__,__LINE__,size);
    printf("[%s][%s][%d] write file start,buffer{%s}\n",__FILE__,__FUNCTION__,__LINE__,buffer);

    if (size == 0)
    {
        printf(" [%s][%s][%d] size is zero\n",__FILE__,__FUNCTION__,__LINE__);
        return -1;
    }
    FILE *wfd =NULL;
    wfd = bs->opaque;
    int ret  = fwrite(buffer,size,1,wfd);
    if (ret  != 1)
        return -1;
    printf("[%s][%s][%d]  write file ok,ret:{%d}\n",__FILE__,__FUNCTION__,__LINE__,ret);

    return 0;
}
void offtout(int32_t x,uint8_t *buf)
{
    int32_t y;

    if(x<0) y=-x; else y=x;

    buf[0]=y%256;y-=buf[0];
    y=y/256;buf[1]=y%256;y-=buf[1];
    y=y/256;buf[2]=y%256;y-=buf[2];
    y=y/256;buf[3]=y%256;

    if(x<0) buf[3]|=0x80;
}
int bsdiff(const uint8_t* old, int32_t oldsize, const uint8_t* new, int32_t newsize, struct bsdiff_stream* stream)
{
    int result;
    struct bsdiff_request req;

    if((req.I=stream->malloc((oldsize+1)*sizeof(int32_t)))==NULL)
        return -1;

    if((req.buffer=stream->malloc(newsize+1))==NULL)
    {
        stream->free(req.I);
        return -1;
    }

    req.old = old;
    req.oldsize = oldsize;
    req.new = new;
    req.newsize = newsize;
    req.stream = stream;

    result = bsdiff_internal(req);

    //stream->free(req.buffer);
    //stream->free(req.I);



    return result;
}
static int bsdiff_internal(const struct bsdiff_request req)
{
    printf("===========================start bsdiff==========================\n");
    int32_t *I,*V;
    int32_t scan,pos,len;
    int32_t lastscan,lastpos,lastoffset;
    int32_t oldscore,scsc;
    int32_t s,Sf,lenf,Sb,lenb;
    int32_t overlap,Ss,lens;
    int32_t i;
    uint8_t *buffer;
     uint8_t buf[8 * 3];
    //uint8_t buf[4*3];

    char *wBuffer;
    int32_t wBufferLen=0;
    int wPos=0;
    int wPosOffset=0;
    if((V=req.stream->malloc((req.oldsize+1)*sizeof(int32_t)))==NULL) return -1;
    I = req.I;

    qsufsort(I,V,req.old,req.oldsize);
    req.stream->free(V);

    wBuffer = req.buffer;

    int blockNum=0;
    int flag=0;
    uint8_t startPoint[8]={'\0'};
    uint32_t start=0;
    uint32_t diffNum=0;
    /* Compute the differences, writing ctrl as we go */
    scan=0;len=0;pos=0;
    lastscan=0;lastpos=0;lastoffset=0;
    char filename[256]={'\0'};

    sprintf(filename,"%s%s",getenv("HOME"),CONFIG_NAME);
    uint32_t basediff =0;
    uint32_t sz = getConfigInt(filename,"LZO_COMPRESS","LZO_BLOCK_SIZE");
    basediff=sz*1024;
    static uint32_t MAX_DIFF_BLOCK = 0;
    MAX_DIFF_BLOCK = getConfigInt(filename,"LZO_COMPRESS","BSDIFF_BLOCK_NUM");

    printf("[%s][%d]basediff : [%d]\n",__FUNCTION__,__LINE__,basediff);
    printf("[%s][%d]MAX_DIFF_BLOCK : [%d]\n",__FUNCTION__,__LINE__,MAX_DIFF_BLOCK);


    while(scan<req.newsize) {
        oldscore=0;
        printf("=====================[%s][%d]scan:[%d],req.newsize:[%d]===============\n",__FUNCTION__,__LINE__,scan,req.newsize);
        for(scsc=scan+=len;scan<req.newsize;scan++) {
            len=search(I,req.old,req.oldsize,req.new+scan,req.newsize-scan,
                       0,req.oldsize,&pos);

            for(;scsc<scan+len;scsc++)
                if((scsc+lastoffset<req.oldsize) &&
                   (req.old[scsc+lastoffset] == req.new[scsc]))
                    oldscore++;

            if(((len==oldscore) && (len!=0)) ||
               (len>oldscore+8)) break;

            if((scan+lastoffset<req.oldsize) &&
               (req.old[scan+lastoffset] == req.new[scan]))
                oldscore--;
        };

        printf("[%s][%d]  start write file data ?? len:{%d}, oldscore:{%d},scan:{%d},req.newsize:{%d}\n",__FUNCTION__,__LINE__,len,oldscore,scan,req.newsize);
        if((len!=oldscore) || (scan==req.newsize))
        {
            s=0;Sf=0;lenf=0;
            for(i=0;(lastscan+i<scan)&&(lastpos+i<req.oldsize);) {
                if(req.old[lastpos+i]==req.new[lastscan+i]) s++;
                i++;
                if(s*2-i>Sf*2-lenf) { Sf=s; lenf=i; };
            };

            lenb=0;
            if(scan<req.newsize) {
                s=0;Sb=0;
                for(i=1;(scan>=lastscan+i)&&(pos>=i);i++) {
                    if(req.old[pos-i]==req.new[scan-i]) s++;
                    if(s*2-i>Sb*2-lenb) { Sb=s; lenb=i; };
                };
            };

            if(lastscan+lenf>scan-lenb) {
                overlap=(lastscan+lenf)-(scan-lenb);
                s=0;Ss=0;lens=0;
                for(i=0;i<overlap;i++) {
                    if(req.new[lastscan+lenf-overlap+i]==
                       req.old[lastpos+lenf-overlap+i]) s++;
                    if(req.new[scan-lenb+i]==
                       req.old[pos-lenb+i]) s--;
                    if(s>Ss) { Ss=s; lens=i+1; };
                };

                lenf+=lens-overlap;
                lenb-=lens;
            };

            printf("[%s][%d]lenf : [%d]\n",__FUNCTION__,__LINE__,lenf);
            printf("[%s][%d]buf : [%s]\n",__FUNCTION__,__LINE__,buf);
            printf("[%s][%d]scan : [%d]\n",__FUNCTION__,__LINE__,scan);
            printf("[%s][%d]lenb : [%d]\n",__FUNCTION__,__LINE__,lenb);
            printf("[%s][%d]lastscan : [%d]\n",__FUNCTION__,__LINE__,lastscan);
            printf("[%s][%d]pos : [%d]\n",__FUNCTION__,__LINE__,pos);
            printf("[%s][%d]lastpos : [%d]\n",__FUNCTION__,__LINE__,lastpos);
            printf("[%s][%d](scan-lenb)-(lastscan+lenf) : [%d]\n",__FUNCTION__,__LINE__,((scan-lenb)-(lastscan+lenf)));
            printf("[%s][%d](pos-lenb)-(lastpos+lenf : [%d]\n",__FUNCTION__,__LINE__,((pos-lenb)-(lastpos+lenf)));


            wBufferLen += sizeof(buf)+lenf+((scan-lenb)-(lastscan+lenf));
            printf("[%s][%d]wBufferLen : [%d]\n",__FUNCTION__,__LINE__,wBufferLen);
            offtout(lenf,buf);
            offtout(((scan-lenb)-(lastscan+lenf)),buf+8);
            offtout(((pos-lenb)-(lastpos+lenf)),buf+16);
            diffNum++;



#if 1
            printf("[%s][%d] start wPos : [%d]\n",__FUNCTION__, __LINE__, wPos);
            printf("[%s][%d] start diffNum : [%d]\n",__FUNCTION__, __LINE__, diffNum);

            if (((wPos+lenf >= basediff+1024)&& (diffNum <= MAX_DIFF_BLOCK)))
            {


                if (wPos == 0)
                    goto BS_NEXT;
                flag = 1;
                uint8_t *sTmp = malloc(wPos+sizeof(startPoint)+1);
                printf("[%s][%d] compress start ,flag ==1>>>>>>>>>>>>>>>>>>>start:[%d]\n",__FUNCTION__,__LINE__,start);
                offtout(start,startPoint);
                memcpy(sTmp,startPoint,sizeof(startPoint));
                memcpy(sTmp+sizeof(startPoint),wBuffer,wPos);
                printf("[%s][%d] compress start basediff+2048,++++++++++++++++wpos:[%d],[%d]\n",__FUNCTION__,__LINE__,wPos+sizeof(startPoint),diffNum);
                //压缩数据
                lzo_bytep lzo_buf = malloc(wPos+sizeof(startPoint)+1);
                lzo_uint lzoUint;
                int r = lzo1x_1_compress(sTmp,(wPos+sizeof(startPoint)),lzo_buf,&lzoUint,wrkmem);
                if (r !=LZO_E_OK )
                {
                    printf("[%s][%d] compress ERROR:[%d]\n",__FUNCTION__,__LINE__,r);
                    return -1;
                }
                printf("[%s][%d] compress end basediff+2048,===========lzoUint:[%d]\n",__FUNCTION__,__LINE__,lzoUint);
                printf("[%s][%d] compress end basediff+2048 blockNum:[%d]\n",__FUNCTION__,__LINE__,blockNum);

                uint8_t TL[16]={'\0'};
                offtout(blockNum,TL);
                offtout(lzoUint,TL+8);
                int ret = -1;
                if (ret = (writedata(req.stream, TL,sizeof(TL))) < 0)
                {
                    printf("[%s][%s][%d] writedata file header  failed\n", __FILE__, __FUNCTION__, __LINE__);
                    return -1;
                }

                if (ret = (writedata(req.stream, lzo_buf,lzoUint)) < 0)
                {
                    printf("[%s][%s][%d] writedata file data  failed\n", __FILE__, __FUNCTION__, __LINE__);
                    return -1;
                }

                wPos=0;
                wBufferLen=0;
                blockNum++;
                diffNum=0;
            }
#endif

            BS_NEXT:
            memcpy(wBuffer+wPos, buf, sizeof(buf));
            printf("[%s][%d] sizeof(buf):[%d],Buffer{%s}\n", __FUNCTION__, __LINE__, sizeof(buf),
                       wBuffer);

            wPos += sizeof(buf);
            printf("[%s][%d]wPos : [%d]\n", __FUNCTION__, __LINE__, wPos);

            for (i = 0; i < lenf; i++)
                wBuffer[wPos + i] = req.new[lastscan + i] - req.old[lastpos + i];
            printf("[%s][%d] wBuffer{%s}\n",  __FUNCTION__, __LINE__, wBuffer);


            wPos += lenf;
            for (i = 0; i < (scan - lenb) - (lastscan + lenf); i++)
                wBuffer[wPos + i] = req.new[lastscan + lenf + i];

            wPos += ((scan - lenb) - (lastscan + lenf));
            printf("[%s][%d] wPos :[%d],wBufferLen:[%d]  wBuffer{%s}\n", __FUNCTION__, __LINE__, wPos,
                       wBufferLen, wBuffer + wPos);


            printf("[%s][%d] Write extra wBufferLen[%d],wBuffer{%s}\n", __FUNCTION__, __LINE__, wBufferLen,
                       wBuffer);

            if( flag ==1)
            {
                memset(startPoint,'\0',sizeof(startPoint));
                printf("[%s][%d] compress start ,flag ==1>>>>>>>>>>>>>>>>>>>lastpos:[%d]\n",__FUNCTION__,__LINE__,lastpos);
                start=lastpos;
                flag=2;
            } else if(flag == 0)
            {
                memset(startPoint,'\0',sizeof(startPoint));
                printf("[%s][%d] compress start ,flag ==0>>>>>>>>>>>>>>>>>>>lastpos:[%d]\n",__FUNCTION__,__LINE__,lastpos);
                start=0;
                flag=2;
            }

#if 1
            if((wPos  >= basediff && diffNum <= MAX_DIFF_BLOCK)||
                    ((wPos < basediff)  && (diffNum == MAX_DIFF_BLOCK ))||
                    ((wPos < basediff) && scan==req.newsize && diffNum <=MAX_DIFF_BLOCK ))
            {
                flag = 1;
                uint8_t *sTmp = malloc(wPos+sizeof(startPoint)+1);
                printf("[%s][%d] compress start ,flag ==1>>>>>>>>>>>>>>>>>>>start:[%d]\n",__FUNCTION__,__LINE__,start);
                offtout(start,startPoint);
                memcpy(sTmp,startPoint,sizeof(startPoint));
                memcpy(sTmp+sizeof(startPoint),wBuffer,wPos);
                printf("[%s][%d] compress start basediff+2048,++++++++++++++++wpos:[%d],[%d]\n",__FUNCTION__,__LINE__,wPos+sizeof(startPoint),diffNum);
                //压缩数据
                lzo_bytep lzo_buf = malloc(wPos+sizeof(startPoint)+1);
                lzo_uint lzoUint;
                int r = lzo1x_1_compress(sTmp,(lzo_uint *)(wPos+sizeof(startPoint)),lzo_buf,&lzoUint,wrkmem);
                if (r !=LZO_E_OK )
                {
                    printf("[%s][%d] compress ERROR:[%d]\n",__FUNCTION__,__LINE__,r);
                    return -1;
                }
                printf("[%s][%d] compress end basediff+2048,===========lzoUint:[%d]\n",__FUNCTION__,__LINE__,lzoUint);
                printf("[%s][%d] compress end basediff+2048 blockNum:[%d]\n",__FUNCTION__,__LINE__,blockNum);

                uint8_t TL[16]={'\0'};
                offtout(blockNum,TL);
                offtout(lzoUint,TL+8);
                int ret = -1;
                if (ret = (writedata(req.stream, TL,sizeof(TL))) < 0)
                {
                    printf("[%s][%s][%d] writedata file header  failed\n", __FILE__, __FUNCTION__, __LINE__);
                    return -1;
                }

                if (ret = (writedata(req.stream, lzo_buf,lzoUint)) < 0)
                {
                    printf("[%s][%s][%d] writedata file data  failed\n", __FILE__, __FUNCTION__, __LINE__);
                    return -1;
                }

                wPos=0;
                wBufferLen=0;
                blockNum++;
                diffNum=0;

            }
#endif



            lastscan = scan - lenb;
            lastpos = pos - lenb;
            lastoffset = pos - scan;

            printf("[%s][%d] Write extra lastscan[%d]\n", __FUNCTION__, __LINE__, lastscan);
            printf("[%s][%d] Write extra lastpos[%d]\n", __FUNCTION__, __LINE__, lastpos);
            printf("[%s][%d] Write extra lastoffset[%d]\n", __FUNCTION__, __LINE__, lastoffset);
            printf("[%s][%d] next wPos : [%d]\n",__FUNCTION__, __LINE__, wPos);
            printf("[%s][%d] start diffNum : [%d]\n",__FUNCTION__, __LINE__, diffNum);

        };



    };

    return 0;
}
static void qsufsort(int32_t *I,int32_t *V,const uint8_t *old,int32_t oldsize)
{
    int32_t buckets[256];
    int32_t i,h,len;

    for(i=0;i<256;i++) buckets[i]=0;
    for(i=0;i<oldsize;i++) buckets[old[i]]++;
    for(i=1;i<256;i++) buckets[i]+=buckets[i-1];
    for(i=255;i>0;i--) buckets[i]=buckets[i-1];
    buckets[0]=0;

    for(i=0;i<oldsize;i++) I[++buckets[old[i]]]=i;
    I[0]=oldsize;
    for(i=0;i<oldsize;i++) V[i]=buckets[old[i]];
    V[oldsize]=0;
    for(i=1;i<256;i++) if(buckets[i]==buckets[i-1]+1) I[buckets[i]]=-1;
    I[0]=-1;

    for(h=1;I[0]!=-(oldsize+1);h+=h) {
        len=0;
        for(i=0;i<oldsize+1;) {
            if(I[i]<0) {
                len-=I[i];
                i-=I[i];
            } else {
                if(len) I[i-len]=-len;
                len=V[I[i]]+1-i;
                split(I,V,i,len,h);
                i+=len;
                len=0;
            };
        };
        if(len) I[i-len]=-len;
    };

    for(i=0;i<oldsize+1;i++) I[V[i]]=i;
}
static int32_t search(const int32_t *I,const uint8_t *old,int32_t oldsize,
                      const uint8_t *new,int32_t newsize,int32_t st,int32_t en,int32_t *pos)
{
    int32_t x,y;

    if(en-st<2) {
        x=matchlen(old+I[st],oldsize-I[st],new,newsize);
        y=matchlen(old+I[en],oldsize-I[en],new,newsize);

        if(x>y) {
            *pos=I[st];
            return x;
        } else {
            *pos=I[en];
            return y;
        }
    };

    x=st+(en-st)/2;
    if(memcmp(old+I[x],new,MIN(oldsize-I[x],newsize))<0) {
        return search(I,old,oldsize,new,newsize,x,en,pos);
    } else {
        return search(I,old,oldsize,new,newsize,st,x,pos);
    };
}
static int32_t writedata(struct bsdiff_stream* stream, const void* buffer, int32_t length)
{
    int32_t result = 0;
    printf("[%s][%s][%d] writedata start \n",__FILE__,__FUNCTION__,__LINE__);
    while (length > 0)
    {
        const int smallsize = (int)MIN(length, INT_MAX);
        const int writeresult = stream->write(stream, buffer, smallsize);
        if (writeresult == -1)
        {
            return -1;
        }
        printf("[%s][%s][%d] writedata sucess,smallsize{%d} \n",__FILE__,__FUNCTION__,__LINE__,smallsize);
        printf("[%s][%s][%d] writedata sucess,writeresult{%d} \n",__FILE__,__FUNCTION__,__LINE__,writeresult);
        result += writeresult;
        length -= smallsize;
        buffer = (uint8_t*)buffer + smallsize;
    }
    printf("[%s][%s][%d] writedata  return sucess \n",__FILE__,__FUNCTION__,__LINE__);

    return result;
}
static void split(int32_t *I,int32_t *V,int32_t start,int32_t len,int32_t h)
{
    int32_t i,j,k,x,tmp,jj,kk;

    if(len<16) {
        for(k=start;k<start+len;k+=j) {
            j=1;x=V[I[k]+h];
            for(i=1;k+i<start+len;i++) {
                if(V[I[k+i]+h]<x) {
                    x=V[I[k+i]+h];
                    j=0;
                };
                if(V[I[k+i]+h]==x) {
                    tmp=I[k+j];I[k+j]=I[k+i];I[k+i]=tmp;
                    j++;
                };
            };
            for(i=0;i<j;i++) V[I[k+i]]=k+j-1;
            if(j==1) I[k]=-1;
        };
        return;
    };

    x=V[I[start+len/2]+h];
    jj=0;kk=0;
    for(i=start;i<start+len;i++) {
        if(V[I[i]+h]<x) jj++;
        if(V[I[i]+h]==x) kk++;
    };
    jj+=start;kk+=jj;

    i=start;j=0;k=0;
    while(i<jj) {
        if(V[I[i]+h]<x) {
            i++;
        } else if(V[I[i]+h]==x) {
            tmp=I[i];I[i]=I[jj+j];I[jj+j]=tmp;
            j++;
        } else {
            tmp=I[i];I[i]=I[kk+k];I[kk+k]=tmp;
            k++;
        };
    };

    while(jj+j<kk) {
        if(V[I[jj+j]+h]==x) {
            j++;
        } else {
            tmp=I[jj+j];I[jj+j]=I[kk+k];I[kk+k]=tmp;
            k++;
        };
    };

    if(jj>start) split(I,V,start,jj-start,h);

    for(i=0;i<kk-jj;i++) V[I[jj+i]]=kk-1;
    if(jj==kk-1) I[jj]=-1;

    if(start+len>kk) split(I,V,kk,start+len-kk,h);
}

static int32_t matchlen(const uint8_t *old,int32_t oldsize,const uint8_t *new,int32_t newsize)
{
    int32_t i;

    for(i=0;(i<oldsize)&&(i<newsize);i++)
        if(old[i]!=new[i]) break;

    return i;
}


int setVersion(char *v,bool flag,int *xv)
{
    int tv=0;
    tv= atoi(v);
    printf("[%s][%s][%d]setVersion tv:[%d]\n",__FILE__,__FUNCTION__,__LINE__,tv);
    if(tv<0||tv >16)
    {
        printf("[%s][%s][%d]版本信息有误，必须在0x10~0xff之间",__FILE__,__FUNCTION__,__LINE__);
        return -1;
    }
    if(flag)
    {
        *xv = tv<<4&0xf0;
    }
    else
    {
        *xv= tv&0x0f;
    }
    printf("[%s][%s][%d]----------xv: %d\n",__FILE__,__FUNCTION__,__LINE__,*xv);
    return 0;
}

int version(char *v,uint8_t *vx)
{

    char *p=NULL;
    p=strstr(v,".");
    printf("p: %s\n",p+1);
    int lv=0x00;
    if((setVersion(p+1,false,&lv)) < 0)
    {
        printf("[%s][%s][%d] lv: %d\n",__FILE__,__FUNCTION__,__LINE__,lv);
        return -1;
    }

    char headv[32]={'\0'};
    memcpy(headv,v,strlen(v)-strlen(p));
    printf(" headv:%s\n",headv);
    int hv=0x00;
    if((setVersion(headv,true,&hv))<0)
    {
        printf("hv: %d\n",hv);
        return -2;
    }
    printf("[%s][%s][%d]+++++++++++++++++++++++++++++++++++++++++\n",__FILE__,__FUNCTION__,__LINE__);
    *vx = hv|lv;
    printf("vv: %d\n",*vx);
    return 0;
}


uint32_t crc32_stream(uint32_t pre_crc, uint8_t *p,  uint32_t len)
{
    int i;
    uint32_t crc = pre_crc;
    while (len--) {
        crc ^= *p++;
        for (i = 0; i < 8; i++)
            crc = (crc >> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
    }
    return crc;
}

uint8_t *getConfigStr(const unsigned char *filename,uint8_t *title,uint8_t *key)
{
    FILE *fp;
    char szLine[1024];
    static uint8_t tmpstr[1024];
    int rtnval;
    int i = 0;
    int flag = 0;
    char *tmp;

    if((fp = fopen(filename, "r")) == NULL)
    {
        printf("have   no   such   file \n");
        return "";
    }
    while(!feof(fp))
    {
        rtnval = fgetc(fp);
        if(rtnval == EOF)
        {
            break;
        }
        else
        {
            szLine[i++] = rtnval;
        }
        if(rtnval == '\n')
        {
            szLine[--i] = '\0';
            i = 0;
            tmp = strchr(szLine, '=');

            if(( tmp != NULL )&&(flag == 1))
            {
                if(strstr(szLine,key)!=NULL)
                {
                    //注释行
                    if ('#' == szLine[0])
                    {
                    }
                    else if ( '\/' == szLine[0] && '\/' == szLine[1] )
                    {

                    }
                    else
                    {
                        //找打key对应变量
                        strcpy(tmpstr,tmp+1);
                        fclose(fp);
                        return tmpstr;
                    }
                }
            }
            else
            {
                strcpy(tmpstr,"[");
                strcat(tmpstr,title);
                strcat(tmpstr,"]");
                if( strncmp(tmpstr,szLine,strlen(tmpstr)) == 0 )
                {
                    //找到title
                    flag = 1;
                }
            }
        }
    }
    fclose(fp);
    return "";
}
uint32_t getConfigInt(const unsigned char *path,uint8_t *title,uint8_t *key)
{
    return atoi(getConfigStr(path,title,key));
}