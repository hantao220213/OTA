//
// Created by hantao on 20-3-18.
//

#ifndef HEXTOBIN_HEX2BIN_H
#define HEXTOBIN_HEX2BIN_H

#ifndef __HEX_H_
#define __HEX_H_
#include<iostream>
#include<stdio.h>
#include<assert.h>
#include <stdlib.h>
#include <string.h>
using  namespace std;
typedef struct{
    int len; //bin文件大小
    int startAddress; //刷写的起始地址
    char *pContent;     //转化后的内容
}HexToBinData;

typedef struct{
    char data[16];//数据
    char len;   //数据长度
    int pos;   //偏移地址
    char type;  //类型
}HexLinData;

int ConvertHexToBin(const char *str,HexToBinData *pData);
//using namespace std;
#endif
#endif //HEXTOBIN_HEX2BIN_H
