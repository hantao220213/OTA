#include "hex2bin.h"

int main(int argc, char *argv[]) {
    HexToBinData binData;
    long filesize=0;
    FILE *fp=NULL;
    char *fileName =argv[1];
    fp = fopen(fileName,"r");
    if(fp == NULL)
    {
        fclose(fp);
        printf(" open file error\n");
        return 0;
    }
    fseek(fp,0,SEEK_END);
    filesize = ftell(fp);
    char *hexBuf = (char *)malloc(filesize+1);
    fseek(fp,0,SEEK_SET);
    fread(hexBuf,1,filesize,fp);

    string tmp = fileName;
    int  npos = tmp.find_last_of('.');
    string binFileName = tmp.substr(0,npos)+".bin";

    FILE *file1 =fopen(binFileName.c_str(),"wb+");

    fseek(file1,0,SEEK_SET);


    int ret = ConvertHexToBin(hexBuf,&binData);
    if(ret < 0)
    {

        printf(" hex to bin error\n");
        goto finsh;
    }
    fwrite(binData.pContent,1,binData.len,file1);


    finsh:
    fclose(fp);
    fclose(file1);
    free(hexBuf);
    //std::cout << "Hello, World!" << std::endl;
    return ret;
}