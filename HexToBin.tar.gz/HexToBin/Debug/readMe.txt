1.使用方式，将需要转换处理的HEX文件，HexToBin 文件，以及hex2bin.sh 放入统一目录下；
2.执行./hex2bin.sh 脚本;
3.当出现如：“A232-S3_1-H3_1-D.hex to  A232-S3_1-H3_1-D.bin sucess”时表示转换成功，在当前目录下可看见HEX转换后对应的BIN文件
4.若出现如：“A232-S3_1-H3_1-D.hex to  A232-S3_1-H3_1-D.bin failed “时表示转换失败;

