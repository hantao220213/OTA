#!/bin/sh
if [ $# -ne 1 ];then
	echo "please input {*.hex} file"

	exit 1;
fi
cat readMe.txt
hexfile=$1
./HexToBin ${hexfile}

if [ $? -eq 0  ];then
	echo ${hexfile} "to " ${hexfile%%.*}".bin" "sucess"
else
	echo ${hexfile} "to " ${hexfile%%.*}".bin" "failed"
fi
